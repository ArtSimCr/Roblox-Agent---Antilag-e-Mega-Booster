const os = require("os");

class HeavyEffectsGuardAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.timer = null;
    this.active = false;
    this.heavyMode = false;

    this.lastCpuSnapshot = this.cpuSnapshot();
    this.lastWarningTime = 0;

    this.onHeavyStart = null;
    this.onHeavyEnd = null;
  }

  cpuSnapshot() {
    const cpus = os.cpus();

    let idle = 0;
    let total = 0;

    for (const cpu of cpus) {
      for (const type of Object.keys(cpu.times)) {
        total += cpu.times[type];
      }

      idle += cpu.times.idle;
    }

    return {
      idle: idle,
      total: total
    };
  }

  getCpuUsage() {
    const current = this.cpuSnapshot();

    const idleDiff = current.idle - this.lastCpuSnapshot.idle;
    const totalDiff = current.total - this.lastCpuSnapshot.total;

    this.lastCpuSnapshot = current;

    if (totalDiff <= 0) {
      return 0;
    }

    return Math.round((1 - idleDiff / totalDiff) * 100);
  }

  getRamUsage() {
    const total = os.totalmem();
    const free = os.freemem();

    if (total <= 0) {
      return 0;
    }

    return Math.round(((total - free) / total) * 100);
  }

  lowerAgentPriority() {
    try {
      os.setPriority(process.pid, 10);

      this.logger.info(
        "HeavyEffectsGuardAgent: prioridade do agente reduzida para não pesar."
      );
    } catch (error) {
      this.logger.warn(
        "HeavyEffectsGuardAgent: não foi possível reduzir prioridade do agente."
      );
    }
  }

  shouldWarnAgain() {
    const cooldown = Number(this.config.heavyEffectsWarningCooldownMs || 120000);

    return Date.now() - this.lastWarningTime >= cooldown;
  }

  enterHeavyMode(cpu, ram) {
    if (this.heavyMode) {
      return;
    }

    this.heavyMode = true;
    this.lastWarningTime = Date.now();

    this.logger.warn("MODO MAPA/EFEITOS PESADOS ATIVADO.");
    this.logger.warn("CPU: " + cpu + "% | RAM: " + ram + "%");
    this.logger.warn(
      "O agente vai pausar verificações extras para deixar o Roblox carregar melhor."
    );
    this.logger.warn(
      "Se o jogo estiver com muitos tiros, sangue ou efeitos, coloque Graphics Quality em 1."
    );

    this.lowerAgentPriority();

    if (typeof this.onHeavyStart === "function") {
      this.onHeavyStart({
        cpu: cpu,
        ram: ram
      });
    }
  }

  exitHeavyMode(cpu, ram) {
    if (!this.heavyMode) {
      return;
    }

    this.heavyMode = false;

    this.logger.info("Modo mapa/efeitos pesados encerrado.");
    this.logger.info("Uso atual: CPU " + cpu + "% | RAM " + ram + "%");
    this.logger.info("Voltando ao modo leve normal.");

    if (typeof this.onHeavyEnd === "function") {
      this.onHeavyEnd({
        cpu: cpu,
        ram: ram
      });
    }
  }

  tick() {
    const cpu = this.getCpuUsage();
    const ram = this.getRamUsage();

    const cpuTrigger = Number(this.config.heavyEffectsCpuTrigger || 82);
    const ramTrigger = Number(this.config.heavyEffectsRamTrigger || 88);

    const cpuRecover = Number(this.config.heavyEffectsCpuRecover || 60);
    const ramRecover = Number(this.config.heavyEffectsRamRecover || 80);

    const isHeavy = cpu >= cpuTrigger || ram >= ramTrigger;
    const isRecovered = cpu <= cpuRecover && ram <= ramRecover;

    if (isHeavy) {
      this.enterHeavyMode(cpu, ram);
      return;
    }

    if (isRecovered) {
      this.exitHeavyMode(cpu, ram);
      return;
    }

    if (this.heavyMode && this.shouldWarnAgain()) {
      this.lastWarningTime = Date.now();

      this.logger.warn(
        "Ainda em modo pesado. CPU " + cpu + "% | RAM " + ram + "%."
      );
    }
  }

  start() {
    if (this.timer) {
      return;
    }

    if (this.config.heavyEffectsGuardEnabled === false) {
      this.logger.info("HeavyEffectsGuardAgent desativado no config.json.");
      return;
    }

    this.active = true;

    const interval = Number(this.config.heavyEffectsCheckInterval || 10000);

    this.logger.info("HeavyEffectsGuardAgent iniciado.");
    this.logger.info(
      "Ele detecta mapa/efeitos pesados e pausa agentes extras temporariamente."
    );
    this.logger.info(
      "Ele não altera arquivos do Roblox, não remove efeitos e não mexe na memória do jogo."
    );

    this.lowerAgentPriority();

    this.timer = setInterval(() => {
      this.tick();
    }, interval);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
    }

    this.timer = null;
    this.active = false;
    this.heavyMode = false;
    this.lastWarningTime = 0;

    this.logger.info("HeavyEffectsGuardAgent parado.");
  }
}

module.exports = HeavyEffectsGuardAgent;