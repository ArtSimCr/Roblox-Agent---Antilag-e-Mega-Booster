const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");

class AfkWarningAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.timer = null;
    this.lastWarningTime = 0;
    this.savedThisIdleSession = false;

    this.saveDir = path.join(__dirname, "..", "saves");
    this.saveFile = path.join(this.saveDir, "afk-session-save.json");

    fs.mkdirSync(this.saveDir, {
      recursive: true
    });
  }

  isWindows() {
    return process.platform === "win32";
  }

  runPowerShell(script, timeout = 10000) {
    return new Promise((resolve) => {
      if (!this.isWindows()) {
        resolve({
          ok: false,
          stdout: "",
          stderr: "",
          error: null
        });

        return;
      }

      const encodedCommand = Buffer.from(script, "utf16le").toString("base64");

      execFile(
        "powershell.exe",
        [
          "-NoProfile",
          "-ExecutionPolicy",
          "Bypass",
          "-EncodedCommand",
          encodedCommand
        ],
        {
          windowsHide: true,
          timeout: timeout
        },
        function (error, stdout, stderr) {
          resolve({
            ok: !error,
            stdout: stdout || "",
            stderr: stderr || "",
            error: error || null
          });
        }
      );
    });
  }

  async getIdleSeconds() {
    if (!this.isWindows()) {
      return 0;
    }

    const script = `
Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class IdleTime {
  [StructLayout(LayoutKind.Sequential)]
  public struct LASTINPUTINFO {
    public uint cbSize;
    public uint dwTime;
  }

  [DllImport("user32.dll")]
  public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

  public static uint GetIdleTime() {
    LASTINPUTINFO info = new LASTINPUTINFO();
    info.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
    GetLastInputInfo(ref info);

    uint tickCount = (uint)Environment.TickCount;
    uint idleMilliseconds = tickCount - info.dwTime;

    return idleMilliseconds / 1000;
  }
}
"@

:GetIdleTime()
`;

    const result = await this.runPowerShell(script);

    const seconds = Number(String(result.stdout).trim());

    if (!Number.isFinite(seconds)) {
      return 0;
    }

    return seconds;
  }

  async beep() {
    if (!this.isWindows()) {
      return;
    }

    const beepCount = Number(this.config.afkBeepCount || 3);

    let script = "";

    for (let i = 0; i < beepCount; i++) {
      script += ":beep(1000, 500);";
      script += "Start-Sleep -Milliseconds 200;";
    }

    await this.runPowerShell(script, 10000);
  }

  saveAfkSession(idleMinutes) {
    const saveData = {
      gameName: this.config.afkGameName || "Roblox",
      targetGame: this.config.afkTargetGame || "Ink Game",
      location: this.config.afkLocation || "Lobby ou sessão atual",
      reason: "Jogador ficou AFK perto do limite de 20 minutos.",
      idleMinutes: idleMinutes,
      savedAt: new Date().toISOString(),
      note: "Save local. Não aperta teclas, não move mouse e não garante voltar ao mesmo servidor."
    };

    fs.writeFileSync(
      this.saveFile,
      JSON.stringify(saveData, null, 2),
      "utf8"
    );

    this.logger.warn("Save local AFK criado.");
    this.logger.warn("Arquivo salvo em: " + this.saveFile);
    this.logger.warn("Motivo: jogador parado perto do limite de 20 minutos.");
  }

  async showWarning(idleMinutes) {
    this.logger.warn(
      "ATENÇÃO: você está parado há cerca de " +
        idleMinutes +
        " minutos."
    );

    this.logger.warn(
      "Volte ao jogo manualmente para evitar desconexão por inatividade."
    );

    if (this.config.afkSound !== false) {
      await this.beep();
    }
  }

  canWarnAgain() {
    const repeatMinutes = Number(this.config.afkWarningRepeatMinutes || 1);
    const repeatMs = repeatMinutes * 60 * 1000;

    return Date.now() - this.lastWarningTime >= repeatMs;
  }

  async tick() {
    const saveAtMinutes = Number(this.config.afkSaveAtMinutes || 18);
    const warnAtMinutes = Number(this.config.afkWarnAtMinutes || 18);

    const idleSeconds = await this.getIdleSeconds();
    const idleMinutes = Math.floor(idleSeconds / 60);

    if (idleMinutes >= saveAtMinutes && this.savedThisIdleSession === false) {
      this.savedThisIdleSession = true;
      this.saveAfkSession(idleMinutes);
    }

    if (idleMinutes >= warnAtMinutes) {
      if (this.canWarnAgain()) {
        this.lastWarningTime = Date.now();
        await this.showWarning(idleMinutes);
      }
    }

    if (idleSeconds < 60) {
      this.lastWarningTime = 0;
      this.savedThisIdleSession = false;
    }
  }

  start() {
    if (this.timer) {
      return;
    }

    if (this.config.afkWarningEnabled === false) {
      this.logger.info("AfkWarningAgent desativado no config.json.");
      return;
    }

    if (!this.isWindows()) {
      this.logger.warn("AfkWarningAgent funciona melhor no Windows.");
      return;
    }

    const interval = Number(this.config.afkCheckInterval || 30000);

    this.logger.info("AfkWarningAgent iniciado.");
    this.logger.info("Ele apenas avisa e cria save local.");
    this.logger.info("Ele não aperta teclas, não move mouse e não mexe no Roblox.");
    this.logger.info(
      "Save local AFK configurado para " +
        Number(this.config.afkSaveAtMinutes || 18) +
        " minutos."
    );

    this.timer = setInterval(() => {
      this.tick();
    }, interval);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
    }

    this.timer = null;
    this.lastWarningTime = 0;
    this.savedThisIdleSession = false;

    this.logger.info("AfkWarningAgent parado.");
  }
}

module.exports = AfkWarningAgent;