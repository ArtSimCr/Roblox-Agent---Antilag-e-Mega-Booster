const os = require("os");
const { exec } = require("child_process");

class MapLoadAssistAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.timer = null;
    this.active = false;

    this.onLoadStart = null;
    this.onLoadEnd = null;
  }

  isWindows() {
    return process.platform === "win32";
  }

  runCommand(command, timeout = 8000) {
    return new Promise((resolve) => {
      exec(
        command,
        {
          windowsHide: true,
          timeout: timeout
        },
        function (error, stdout, stderr) {
          resolve({
            ok: !error,
            stdout: stdout || "",
            stderr: stderr || "",
            error: error || null
          });
        }
      );
    });
  }

  lowerAgentPriority() {
    try {
      os.setPriority(process.pid, 10);

      this.logger.info(
        "MapLoadAssistAgent: prioridade do agente reduzida durante carregamento."
      );
    } catch (error) {
      this.logger.warn(
        "MapLoadAssistAgent: não foi possível reduzir a prioridade do agente."
      );
    }
  }

  async lightDnsWarmup() {
    if (!this.isWindows()) {
      return;
    }

    if (this.config.mapLoadDnsWarmup !== true) {
      return;
    }

    this.logger.info("MapLoadAssistAgent: fazendo verificação DNS leve.");

    await this.runCommand("nslookup roblox.com", 6000);
  }

  startLoadingWindow() {
    if (this.active) {
      return;
    }

    if (this.config.mapLoadAssistEnabled === false) {
      this.logger.info("MapLoadAssistAgent desativado no config.json.");
      return;
    }

    this.active = true;

    const durationMs = Number(this.config.mapLoadAssistDurationMs || 180000);
    const durationSeconds = Math.round(durationMs / 1000);

    this.logger.info("MapLoadAssistAgent iniciado.");
    this.logger.info(
      "Modo carregamento de mapa ativado por " + durationSeconds + " segundos."
    );
    this.logger.info(
      "Durante esse tempo, agentes extras ficam atrasados para sobrar recurso ao Roblox."
    );

    this.lowerAgentPriority();

    this.lightDnsWarmup();

    if (typeof this.onLoadStart === "function") {
      this.onLoadStart();
    }

    this.timer = setTimeout(() => {
      this.finishLoadingWindow();
    }, durationMs);
  }

  finishLoadingWindow() {
    if (!this.active) {
      return;
    }

    this.active = false;

    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.timer = null;

    this.logger.info("MapLoadAssistAgent: janela de carregamento encerrada.");
    this.logger.info("Restaurando agentes leves normais.");

    if (typeof this.onLoadEnd === "function") {
      this.onLoadEnd();
    }
  }

  stop() {
    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.timer = null;
    this.active = false;

    this.logger.info("MapLoadAssistAgent parado.");
  }
}

module.exports = MapLoadAssistAgent;