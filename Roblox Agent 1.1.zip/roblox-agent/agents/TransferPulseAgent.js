const os = require("os");

class TransferPulseAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.active = false;
    this.timer = null;
    this.keyboardEnabled = false;

    this.onPulseStart = null;
    this.onPulseEnd = null;
  }

  lowerAgentPriority() {
    try {
      os.setPriority(process.pid, 10);

      this.logger.info(
        "TransferPulseAgent: prioridade do agente reduzida durante a transferência."
      );
    } catch (error) {
      this.logger.warn(
        "TransferPulseAgent: não foi possível reduzir prioridade do agente."
      );
    }
  }

  startPulse(reason) {
    if (this.active) {
      this.logger.info("TransferPulseAgent: pulso de transferência já está ativo.");
      return;
    }

    if (this.config.transferPulseEnabled === false) {
      this.logger.info("TransferPulseAgent desativado no config.json.");
      return;
    }

    this.active = true;

    const durationMs = Number(this.config.transferPulseDurationMs || 90000);
    const durationSeconds = Math.round(durationMs / 1000);

    this.logger.warn("TRANSFER PULSE ATIVADO.");
    this.logger.warn("Motivo: " + (reason || "transição manual"));
    this.logger.warn(
      "Modo ultra leve temporário por " + durationSeconds + " segundos."
    );
    this.logger.warn(
      "Use isso antes/depois de clicar no botão azul de troca de servidor."
    );

    this.lowerAgentPriority();

    if (typeof this.onPulseStart === "function") {
      this.onPulseStart();
    }

    this.timer = setTimeout(() => {
      this.stopPulse();
    }, durationMs);
  }

  stopPulse() {
    if (!this.active) {
      return;
    }

    this.active = false;

    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.timer = null;

    this.logger.info("TransferPulseAgent: pulso de transferência encerrado.");

    if (typeof this.onPulseEnd === "function") {
      this.onPulseEnd();
    }
  }

  startKeyboardListener() {
    if (this.keyboardEnabled) {
      return;
    }

    if (this.config.transferPulseKeyboard !== true) {
      return;
    }

    if (!process.stdin.isTTY) {
      this.logger.warn(
        "TransferPulseAgent: terminal não suporta leitura de tecla."
      );
      return;
    }

    this.keyboardEnabled = true;

    this.logger.info("TransferPulseAgent: atalho do terminal ativado.");
    this.logger.info("Pressione T no terminal para ativar pulso de transferência.");
    this.logger.info("Pressione Q no terminal para parar o pulso.");

    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding("utf8");

    process.stdin.on("data", (key) => {
      const value = String(key).toLowerCase();

      if (value === "t") {
        this.startPulse("atalho T pressionado no terminal");
      }

      if (value === "q") {
        this.stopPulse();
      }

      if (key === "\u0003") {
        process.emit("SIGINT");
      }
    });
  }

  stopKeyboardListener() {
    if (!this.keyboardEnabled) {
      return;
    }

    this.keyboardEnabled = false;

    try {
      if (process.stdin.isTTY) {
        process.stdin.setRawMode(false);
      }

      process.stdin.pause();
    } catch (error) {
      // Ignora erro ao fechar terminal.
    }
  }

  stop() {
    this.stopPulse();
    this.stopKeyboardListener();

    this.logger.info("TransferPulseAgent parado.");
  }
}

module.exports = TransferPulseAgent;