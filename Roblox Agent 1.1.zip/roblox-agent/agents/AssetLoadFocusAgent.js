const os = require("os");

class AssetLoadFocusAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.active = false;
    this.timer = null;

    this.onFocusStart = null;
    this.onFocusEnd = null;
  }

  lowerAgentPriority() {
    try {
      os.setPriority(process.pid, 10);

      this.logger.info(
        "AssetLoadFocusAgent: prioridade do agente reduzida durante carregamento de assets."
      );
    } catch (error) {
      this.logger.warn(
        "AssetLoadFocusAgent: não foi possível reduzir prioridade do agente."
      );
    }
  }

  startFocus(reason) {
    if (this.active) {
      this.logger.info("AssetLoadFocusAgent: foco de carregamento já está ativo.");
      return;
    }

    if (this.config.assetLoadFocusEnabled === false) {
      this.logger.info("AssetLoadFocusAgent desativado no config.json.");
      return;
    }

    this.active = true;

    const durationMs = Number(this.config.assetLoadFocusDurationMs || 180000);
    const durationSeconds = Math.round(durationMs / 1000);

    this.logger.warn("FOCO DE CARREGAMENTO DE ASSETS ATIVADO.");
    this.logger.warn("Motivo: " + (reason || "entrada/carregamento de jogo"));
    this.logger.warn(
      "Durante " +
        durationSeconds +
        " segundos, agentes extras ficam pausados para ajudar o Roblox a carregar mapa, skins, cores, som e efeitos."
    );
    this.logger.warn(
      "O agente não mexe nos arquivos do Roblox e não altera o jogo por dentro."
    );

    this.lowerAgentPriority();

    if (typeof this.onFocusStart === "function") {
      this.onFocusStart();
    }

    this.timer = setTimeout(() => {
      this.stopFocus();
    }, durationMs);
  }

  stopFocus() {
    if (!this.active) {
      return;
    }

    this.active = false;

    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.timer = null;

    this.logger.info("AssetLoadFocusAgent: foco de carregamento encerrado.");

    if (typeof this.onFocusEnd === "function") {
      this.onFocusEnd();
    }
  }

  stop() {
    this.stopFocus();

    this.logger.info("AssetLoadFocusAgent parado.");
  }
}

module.exports = AssetLoadFocusAgent;