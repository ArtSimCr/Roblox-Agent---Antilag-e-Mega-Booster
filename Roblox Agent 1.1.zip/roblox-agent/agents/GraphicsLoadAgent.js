const { execFile } = require("child_process");
const os = require("os");

class GraphicsLoadAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.timer = null;
    this.mode = "NORMAL_LIGHT";
    this.lastCpuSnapshot = this.cpuSnapshot();

    this.onMegaLight = null;
    this.onNormalLight = null;
  }

  isWindows() {
    return process.platform === "win32";
  }

  cpuSnapshot() {
    const cpus = os.cpus();

    let idle = 0;
    let total = 0;

    for (const cpu of cpus) {
      for (const type of Object.keys(cpu.times)) {
        total += cpu.times[type];
      }

      idle += cpu.times.idle;
    }

    return {
      idle: idle,
      total: total
    };
  }

  getCpuUsage() {
    const current = this.cpuSnapshot();

    const idleDiff = current.idle - this.lastCpuSnapshot.idle;
    const totalDiff = current.total - this.lastCpuSnapshot.total;

    this.lastCpuSnapshot = current;

    if (totalDiff <= 0) {
      return 0;
    }

    return Math.round((1 - idleDiff / totalDiff) * 100);
  }

  runPowerShell(script, timeout = 10000) {
    return new Promise((resolve) => {
      if (!this.isWindows()) {
        resolve({
          ok: false,
          stdout: "",
          stderr: "",
          error: null
        });

        return;
      }

      const encodedCommand = Buffer
        .from(script, "utf16le")
        .toString("base64");

      execFile(
        "powershell.exe",
        [
          "-NoProfile",
          "-ExecutionPolicy",
          "Bypass",
          "-EncodedCommand",
          encodedCommand
        ],
        {
          windowsHide: true,
          timeout: timeout
        },
        function (error, stdout, stderr) {
          resolve({
            ok: !error,
            stdout: stdout || "",
            stderr: stderr || "",
            error: error || null
          });
        }
      );
    });
  }

  async getGpuUsage() {
    if (!this.isWindows()) {
      return null;
    }

    const script = `
try {
  $samples = (Get-Counter "\\GPU Engine(*)\\Utilization Percentage").CounterSamples
  $sum = ($samples | Measure-Object CookedValue -Sum).Sum
  :Round($sum, 0)
} catch {
  Write-Output "NA"
}
`;

    const result = await this.runPowerShell(script, 10000);

    const value = Number(String(result.stdout).trim());

    if (!Number.isFinite(value)) {
      return null;
    }

    if (value > 100) {
      return 100;
    }

    if (value < 0) {
      return 0;
    }

    return value;
  }

  async checkLoad() {
    const cpu = this.getCpuUsage();
    const gpu = await this.getGpuUsage();

    const cpuLimit = Number(this.config.megaLightCpuTrigger || 85);
    const gpuLimit = Number(this.config.megaLightGpuTrigger || 85);

    let heavy = false;

    if (cpu >= cpuLimit) {
      heavy = true;
    }

    if (gpu !== null && gpu >= gpuLimit) {
      heavy = true;
    }

    if (heavy && this.mode !== "MEGA_LIGHT") {
      this.mode = "MEGA_LIGHT";

      this.logger.warn("Modo MEGA SUPER LEVE ativado.");
      this.logger.warn("Uso alto detectado: CPU " + cpu + "%" + (gpu !== null ? " | GPU " + gpu + "%" : ""));
      this.logger.warn("Se o gráfico do Roblox estiver alto, coloque Graphics Quality em 1 para reduzir lag.");

      if (typeof this.onMegaLight === "function") {
        this.onMegaLight({
          cpu: cpu,
          gpu: gpu
        });
      }

      return;
    }

    const cpuRecover = Number(this.config.normalLightCpuRecover || 65);
    const gpuRecover = Number(this.config.normalLightGpuRecover || 65);

    let recovered = cpu <= cpuRecover;

    if (gpu !== null) {
      recovered = recovered && gpu <= gpuRecover;
    }

    if (recovered && this.mode !== "NORMAL_LIGHT") {
      this.mode = "NORMAL_LIGHT";

      this.logger.info("Modo leve normal restaurado.");
      this.logger.info("Uso atual: CPU " + cpu + "%" + (gpu !== null ? " | GPU " + gpu + "%" : ""));

      if (typeof this.onNormalLight === "function") {
        this.onNormalLight({
          cpu: cpu,
          gpu: gpu
        });
      }
    }
  }

  start() {
    if (this.timer) {
      return;
    }

    if (this.config.graphicsLoadAgentEnabled === false) {
      this.logger.info("GraphicsLoadAgent desativado no config.json.");
      return;
    }

    const interval = Number(this.config.graphicsLoadCheckInterval || 15000);

    this.logger.info("GraphicsLoadAgent iniciado.");
    this.logger.info("Ele detecta peso alto por CPU/GPU e alterna o modo de leveza.");
    this.logger.info("Ele não altera arquivos nem configurações internas do Roblox.");

    this.timer = setInterval(() => {
      this.checkLoad();
    }, interval);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
    }

    this.timer = null;
    this.mode = "NORMAL_LIGHT";

    this.logger.info("GraphicsLoadAgent parado.");
  }
}

module.exports = GraphicsLoadAgent;