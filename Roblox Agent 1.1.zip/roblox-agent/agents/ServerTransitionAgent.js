const { exec } = require("child_process");
const os = require("os");

class ServerTransitionAgent {
  constructor(logger, config) {
    this.logger = logger;
    this.config = config;

    this.timer = null;
    this.active = false;
    this.lastNetworkWarning = 0;
  }

  isWindows() {
    return process.platform === "win32";
  }

  runCommand(command, timeout = 8000) {
    return new Promise((resolve) => {
      exec(
        command,
        {
          windowsHide: true,
          timeout: timeout
        },
        function (error, stdout, stderr) {
          resolve({
            ok: !error,
            stdout: stdout || "",
            stderr: stderr || "",
            error: error || null
          });
        }
      );
    });
  }

  lowerAgentPriority() {
    try {
      os.setPriority(process.pid, 10);
      this.logger.info("ServerTransitionAgent: prioridade do agente reduzida.");
    } catch (error) {
      this.logger.warn(
        "ServerTransitionAgent: não foi possível reduzir prioridade do agente."
      );
    }
  }

  parsePing(output) {
    const lossMatch = output.match(/(\d+)%\s*(?:loss|perda)/i);

    const averageMatch = output.match(
      /Average\s*=\s*(\d+)ms|M[ée]dia\s*=\s*(\d+)ms/i
    );

    const loss = lossMatch ? Number(lossMatch[1]) : null;

    const average = averageMatch
      ? Number(averageMatch[1] || averageMatch[2])
      : null;

    return {
      loss: loss,
      average: average
    };
  }

  async checkNetworkLight() {
    if (!this.isWindows()) {
      return;
    }

    const target = this.config.transitionNetworkTarget || "8.8.8.8";

    const result = await this.runCommand("ping -n 2 " + target, 7000);

    if (!result.ok || !result.stdout) {
      this.warnNetwork("Rede instável: não foi possível completar ping leve.");
      return;
    }

    const stats = this.parsePing(result.stdout);

    if (stats.loss !== null && stats.loss > 0) {
      this.warnNetwork(
        "Perda de pacotes detectada: " +
          stats.loss +
          "%. Isso pode deixar troca de servidor mais lenta."
      );
    }

    if (stats.average !== null && stats.average > 150) {
      this.warnNetwork(
        "Ping alto detectado: " +
          stats.average +
          "ms. Trocas de servidor podem demorar mais."
      );
    }
  }

  warnNetwork(message) {
    const cooldownMs = Number(this.config.transitionWarningCooldownMs || 120000);

    if (Date.now() - this.lastNetworkWarning < cooldownMs) {
      return;
    }

    this.lastNetworkWarning = Date.now();

    this.logger.warn(message);
  }

  start() {
    if (this.timer) {
      return;
    }

    if (this.config.serverTransitionAgentEnabled === false) {
      this.logger.info("ServerTransitionAgent desativado no config.json.");
      return;
    }

    this.active = true;

    this.logger.info("ServerTransitionAgent iniciado.");
    this.logger.info("Modo troca de servidor leve ativado.");
    this.logger.info("O agente não mexe no Roblox; apenas reduz peso local.");

    this.lowerAgentPriority();

    const interval = Number(this.config.transitionCheckInterval || 60000);

    this.timer = setInterval(() => {
      this.checkNetworkLight();
    }, interval);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
    }

    this.timer = null;
    this.active = false;

    this.logger.info("ServerTransitionAgent parado.");
  }
}

module.exports = ServerTransitionAgent;