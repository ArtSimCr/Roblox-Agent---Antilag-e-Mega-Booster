const fs = require("fs");
const path = require("path");

const Logger = require("./utils/Logger");
const RobloxAgent = require("./agents/RobloxAgent");
const GameBoostAgent = require("./agents/GameBoostAgent");
const AfkWarningAgent = require("./agents/AfkWarningAgent");
const ServerTransitionAgent = require("./agents/ServerTransitionAgent");
const GraphicsLoadAgent = require("./agents/GraphicsLoadAgent");
const MapLoadAssistAgent = require("./agents/MapLoadAssistAgent");
const HeavyEffectsGuardAgent = require("./agents/HeavyEffectsGuardAgent");
const TransferPulseAgent = require("./agents/TransferPulseAgent");
const AssetLoadFocusAgent = require("./agents/AssetLoadFocusAgent");

function loadConfig() {
  const configPath = path.join(__dirname, "config.json");

  const defaultConfig = {
    autoStart: true,
    monitorInterval: 60000,
    logging: true,
    ultraLightMode: true,
    boostRobloxPriority: true,

    afkWarningEnabled: true,
    afkSaveAtMinutes: 18,
    afkWarnAtMinutes: 18,
    afkWarningRepeatMinutes: 1,
    afkCheckInterval: 30000,
    afkBeepCount: 4,
    afkSound: true,

    afkGameName: "Roblox",
    afkTargetGame: "Ink Game",
    afkLocation: "Lobby ou sessão atual",

    serverTransitionAgentEnabled: true,
    transitionCheckInterval: 90000,
    transitionNetworkTarget: "8.8.8.8",
    transitionWarningCooldownMs: 120000,

    graphicsLoadAgentEnabled: true,
    graphicsLoadCheckInterval: 45000,
    megaLightCpuTrigger: 85,
    megaLightGpuTrigger: 85,
    normalLightCpuRecover: 65,
    normalLightGpuRecover: 65,

    mapLoadAssistEnabled: true,
    mapLoadAssistDurationMs: 180000,
    mapLoadDnsWarmup: true,

    heavyEffectsGuardEnabled: true,
    heavyEffectsCheckInterval: 30000,
    heavyEffectsCpuTrigger: 82,
    heavyEffectsRamTrigger: 88,
    heavyEffectsCpuRecover: 60,
    heavyEffectsRamRecover: 80,
    heavyEffectsWarningCooldownMs: 120000,

    transferPulseEnabled: true,
    transferPulseKeyboard: true,
    transferPulseDurationMs: 90000,

    assetLoadFocusEnabled: true,
    assetLoadFocusDurationMs: 180000,

    protectServerTransitionDuringHeavy: true,
    protectServerTransitionDuringAssetLoad: true,
    protectServerTransitionDuringMapLoad: true
  };

  if (!fs.existsSync(configPath)) {
    return defaultConfig;
  }

  try {
    const fileContent = fs.readFileSync(configPath, "utf8");
    const userConfig = JSON.parse(fileContent);

    return {
      ...defaultConfig,
      ...userConfig
    };
  } catch (error) {
    console.log("Erro ao carregar config.json. Usando configuração padrão.");
    return defaultConfig;
  }
}

class MainAgent {
  constructor() {
    this.config = loadConfig();

    this.logger = new Logger(this.config.logging);

    this.robloxAgent = new RobloxAgent(this.logger, this.config);
    this.gameBoostAgent = new GameBoostAgent(this.logger, this.config);
    this.afkWarningAgent = new AfkWarningAgent(this.logger, this.config);

    this.serverTransitionAgent = new ServerTransitionAgent(
      this.logger,
      this.config
    );

    this.graphicsLoadAgent = new GraphicsLoadAgent(
      this.logger,
      this.config
    );

    this.mapLoadAssistAgent = new MapLoadAssistAgent(
      this.logger,
      this.config
    );

    this.heavyEffectsGuardAgent = new HeavyEffectsGuardAgent(
      this.logger,
      this.config
    );

    this.transferPulseAgent = new TransferPulseAgent(
      this.logger,
      this.config
    );

    this.assetLoadFocusAgent = new AssetLoadFocusAgent(
      this.logger,
      this.config
    );

    this.robloxRunning = false;

    this.setupAgentCallbacks();
  }

  setupAgentCallbacks() {
    this.mapLoadAssistAgent.onLoadStart = () => {
      this.logger.info("Modo carregamento de mapa ativado.");
      this.logger.info("Pausando agentes extras para deixar o Roblox carregar melhor.");

      this.afkWarningAgent.stop();

      if (this.config.protectServerTransitionDuringMapLoad === true) {
        this.logger.info("ServerTransitionAgent protegido durante carregamento de mapa.");
        this.serverTransitionAgent.start();
      } else {
        this.serverTransitionAgent.stop();
      }
    };

    this.mapLoadAssistAgent.onLoadEnd = () => {
      if (
        this.robloxRunning === true &&
        this.heavyEffectsGuardAgent.heavyMode === false &&
        this.graphicsLoadAgent.mode !== "MEGA_LIGHT" &&
        this.transferPulseAgent.active === false &&
        this.assetLoadFocusAgent.active === false
      ) {
        this.logger.info("Janela de carregamento encerrada.");
        this.logger.info("Voltando ao modo leve normal.");

        this.afkWarningAgent.start();
        this.serverTransitionAgent.start();
      }
    };

    this.assetLoadFocusAgent.onFocusStart = () => {
      this.logger.warn("AssetLoadFocusAgent ativado.");
      this.logger.warn("Foco em carregar mapa, skins, cores, sons e efeitos.");
      this.logger.warn("Agentes extras ficam pausados para evitar lag no começo.");

      this.afkWarningAgent.stop();
      this.mapLoadAssistAgent.stop();

      if (this.config.protectServerTransitionDuringAssetLoad === true) {
        this.logger.info("ServerTransitionAgent protegido durante carregamento de assets.");
        this.serverTransitionAgent.start();
      } else {
        this.serverTransitionAgent.stop();
      }
    };

    this.assetLoadFocusAgent.onFocusEnd = () => {
      if (this.robloxRunning === true) {
        this.logger.info("Carregamento inicial encerrado.");
        this.logger.info("Agora iniciando agentes extras com atraso seguro.");

        if (this.heavyEffectsGuardAgent.heavyMode === false) {
          this.afkWarningAgent.start();
        }

        this.serverTransitionAgent.start();

        if (this.graphicsLoadAgent.mode !== "MEGA_LIGHT") {
          this.graphicsLoadAgent.start();
        }

        this.heavyEffectsGuardAgent.start();

        this.logger.info("Agentes extras iniciados após carregamento.");
      }
    };

    this.graphicsLoadAgent.onMegaLight = () => {
      this.logger.warn("Modo MEGA SUPER LEVE ativado.");
      this.logger.warn("Reduzindo verificações extras para diminuir peso.");

      if (this.config.protectServerTransitionDuringHeavy === true) {
        this.logger.info("ServerTransitionAgent protegido durante modo MEGA SUPER LEVE.");
        this.serverTransitionAgent.start();
      } else {
        this.serverTransitionAgent.stop();
      }
    };

    this.graphicsLoadAgent.onNormalLight = () => {
      if (
        this.robloxRunning === true &&
        this.mapLoadAssistAgent.active === false &&
        this.heavyEffectsGuardAgent.heavyMode === false &&
        this.transferPulseAgent.active === false &&
        this.assetLoadFocusAgent.active === false
      ) {
        this.logger.info("Modo leve normal restaurado pelo GraphicsLoadAgent.");

        this.serverTransitionAgent.start();
      }
    };

    this.heavyEffectsGuardAgent.onHeavyStart = () => {
      this.logger.warn("HeavyEffectsGuardAgent detectou mapa/efeitos pesados.");
      this.logger.warn("Pausando agentes extras para reduzir travamentos.");

      this.afkWarningAgent.stop();

      if (this.config.protectServerTransitionDuringHeavy === true) {
        this.logger.info("ServerTransitionAgent protegido durante efeitos pesados.");
        this.serverTransitionAgent.start();
      } else {
        this.serverTransitionAgent.stop();
      }
    };

    this.heavyEffectsGuardAgent.onHeavyEnd = () => {
      if (
        this.robloxRunning === true &&
        this.mapLoadAssistAgent.active === false &&
        this.graphicsLoadAgent.mode !== "MEGA_LIGHT" &&
        this.transferPulseAgent.active === false &&
        this.assetLoadFocusAgent.active === false
      ) {
        this.logger.info("HeavyEffectsGuardAgent: efeitos pesados aliviaram.");
        this.logger.info("Restaurando agentes leves.");

        this.afkWarningAgent.start();
        this.serverTransitionAgent.start();
      }
    };

    this.transferPulseAgent.onPulseStart = () => {
      this.logger.warn("TransferPulseAgent ativado.");
      this.logger.warn("Modo de troca de servidor protegido ativado.");

      this.afkWarningAgent.stop();
      this.mapLoadAssistAgent.stop();

      this.serverTransitionAgent.start();

      if (this.config.assetLoadFocusEnabled !== false) {
        this.assetLoadFocusAgent.startFocus("transferência de servidor iniciada");
      }
    };

    this.transferPulseAgent.onPulseEnd = () => {
      if (
        this.robloxRunning === true &&
        this.heavyEffectsGuardAgent.heavyMode === false &&
        this.graphicsLoadAgent.mode !== "MEGA_LIGHT" &&
        this.assetLoadFocusAgent.active === false
      ) {
        this.logger.info("TransferPulseAgent encerrado.");
        this.logger.info("Restaurando agentes leves.");

        this.afkWarningAgent.start();
        this.serverTransitionAgent.start();
      }
    };
  }

  start() {
    this.logger.info("Roblox Performance Agent iniciado.");
    this.logger.info(
      "Modo leve + GameBoost + AFK Warning + ServerTransition + GraphicsLoad + MapLoadAssist + HeavyEffectsGuard + TransferPulse + AssetLoadFocus ativado."
    );
    this.logger.info("Nenhum arquivo do Roblox será modificado.");
    this.logger.info("Nenhuma memória do jogo será alterada.");
    this.logger.info("Nenhum processo será fechado automaticamente.");

    if (process.argv.includes("--check")) {
      this.logger.info("Verificação concluída.");
      return;
    }

    this.robloxAgent.on("stateChanged", async (state, robloxInfo) => {
      if (state === "Executando" && this.robloxRunning === false) {
        this.robloxRunning = true;

        this.logger.info("Roblox detectado.");
        this.logger.info("Ativando somente o essencial para não causar lag no carregamento...");

        await this.gameBoostAgent.activate();

        this.logger.info("Iniciando TransferPulseAgent...");
        this.transferPulseAgent.startKeyboardListener();

        if (this.config.assetLoadFocusEnabled !== false) {
          this.logger.info("Iniciando AssetLoadFocusAgent...");
          this.assetLoadFocusAgent.startFocus("Roblox acabou de entrar/carregar jogo");
        } else {
          this.logger.info("AssetLoadFocusAgent desativado. Iniciando agentes leves direto.");

          this.afkWarningAgent.start();
          this.serverTransitionAgent.start();
          this.graphicsLoadAgent.start();
          this.heavyEffectsGuardAgent.start();
        }

        this.logger.info("Modo inicial de carregamento seguro ativado.");
      }

      if (state === "Fechado" && this.robloxRunning === true) {
        this.robloxRunning = false;

        this.logger.info("Roblox fechado.");
        this.logger.info("Parando agentes...");

        this.afkWarningAgent.stop();
        this.serverTransitionAgent.stop();
        this.graphicsLoadAgent.stop();
        this.mapLoadAssistAgent.stop();
        this.heavyEffectsGuardAgent.stop();
        this.transferPulseAgent.stop();
        this.assetLoadFocusAgent.stop();

        await this.gameBoostAgent.restore();

        this.logger.info("Agente voltou ao modo de espera.");
      }
    });

    this.robloxAgent.start();
  }

  async shutdown() {
    this.logger.info("Encerrando agente...");

    this.robloxAgent.stop();
    this.afkWarningAgent.stop();
    this.serverTransitionAgent.stop();
    this.graphicsLoadAgent.stop();
    this.mapLoadAssistAgent.stop();
    this.heavyEffectsGuardAgent.stop();
    this.transferPulseAgent.stop();
    this.assetLoadFocusAgent.stop();

    await this.gameBoostAgent.restore();

    this.logger.info("Agente encerrado.");

    process.exit(0);
  }
}

const app = new MainAgent();

process.on("SIGINT", async function () {
  await app.shutdown();
});

process.on("SIGTERM", async function () {
  await app.shutdown();
});

app.start();